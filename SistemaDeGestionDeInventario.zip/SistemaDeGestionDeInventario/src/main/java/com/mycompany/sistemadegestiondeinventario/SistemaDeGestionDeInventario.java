package com.mycompany.sistemadegestiondeinventario;


import java.util.ArrayList;
import java.util.Scanner;

// Clase Producto
class Producto {
    private String nombre;
    private Categoria categoria;
    private int cantidad;
    private double precio;
    private Proveedor proveedor;  // Agregado un proveedor a cada producto

    // Constructor
    public Producto(String nombre, Categoria categoria, int cantidad, double precio, Proveedor proveedor) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.cantidad = cantidad;
        this.precio = precio;
        this.proveedor = proveedor;
    }

    // Métodos getter y setter
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public Proveedor getProveedor() { return proveedor; }
    public void setProveedor(Proveedor proveedor) { this.proveedor = proveedor; }

    // Método para mostrar información del producto
    public void mostrarProducto() {
        System.out.println("Producto: " + nombre);
        System.out.println("Categoria: " + categoria.getNombre());
        System.out.println("Cantidad en stock: " + cantidad);
        System.out.println("Precio: $" + precio);
        System.out.println("Proveedor: " + proveedor.getNombre());
    }

    // Método para verificar si el stock está bajo
    public boolean isStockBajo() {
        return cantidad < 10;  // Consideramos que un stock bajo es menor a 10
    }
}

// Clase Categoria
class Categoria {
    private String nombre;

    // Constructor
    public Categoria(String nombre) {
        this.nombre = nombre;
    }

    // Getter y Setter
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
}

// Clase Proveedor
class Proveedor {
    private String nombre;
    private String direccion;
    private String telefono;

    // Constructor
    public Proveedor(String nombre, String direccion, String telefono) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    // Métodos getter y setter
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
}

// Clase SistemaInventario
class SistemaInventario {
    private final ArrayList<Producto> productos;
    private final ArrayList<Categoria> categorias;
    private final ArrayList<Proveedor> proveedores;

    // Constructor
    public SistemaInventario() {
        productos = new ArrayList<>();
        categorias = new ArrayList<>();
        proveedores = new ArrayList<>();
    }

    // Métodos para agregar productos, categorías y proveedores
    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public void agregarCategoria(Categoria categoria) {
        categorias.add(categoria);
    }

    public void agregarProveedor(Proveedor proveedor) {
        proveedores.add(proveedor);
    }

    // Método para mostrar productos con stock bajo
    public void mostrarProductosConStockBajo() {
        for (Producto producto : productos) {
            if (producto.isStockBajo()) {
                producto.mostrarProducto();
            }
        }
    }

    // Método para mostrar todos los productos
    public void mostrarProductos() {
        for (Producto producto : productos) {
            producto.mostrarProducto();
        }
    }
}

// Clase Main
public class SistemaDeGestionDeInventario  {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            SistemaInventario sistema = new SistemaInventario();
            
            // Crear algunos objetos de ejemplo
            Categoria categoria1 = new Categoria("Electronica");
            Proveedor proveedor1 = new Proveedor("Proveedor A", "Calle 123", "123456789");
            
            // Agregar categorías y proveedores al sistema
            sistema.agregarCategoria(categoria1);
            sistema.agregarProveedor(proveedor1);
            
            boolean continuar = true;
            while (continuar) {
                System.out.println("\nSistema de Gestion de Inventarios");
                System.out.println("1. Agregar Producto");
                System.out.println("2. Mostrar Productos");
                System.out.println("3. Mostrar Productos con Stock Bajo");
                System.out.println("4. Salir");
                System.out.print("Elija una opcion: ");
                
                try {
                    int opcion = Integer.parseInt(scanner.nextLine());
                    switch (opcion) {
                        case 1 -> {
                            System.out.print("Ingrese el nombre del producto: ");
                            String nombre = scanner.nextLine();
                            System.out.print("Ingrese la categoria del producto: ");
                            String nombreCategoria = scanner.nextLine();
                            Categoria categoria = new Categoria(nombreCategoria); // Busca o crea la categoría
                            System.out.print("Ingrese la cantidad del producto: ");
                            int cantidad = Integer.parseInt(scanner.nextLine());
                            System.out.print("Ingrese el precio del producto: ");
                            double precio = Double.parseDouble(scanner.nextLine());
                            System.out.print("Ingrese el nombre del proveedor: ");
                            String nombreProveedor = scanner.nextLine();
                            Proveedor proveedor = new Proveedor(nombreProveedor, "Desconocida", "Sin teléfono"); // Crea un proveedor ejemplo
                            
                            Producto producto = new Producto(nombre, categoria, cantidad, precio, proveedor);
                            sistema.agregarProducto(producto);
                        }
                            

                        case 2 -> sistema.mostrarProductos();
                            
                        case 3 -> sistema.mostrarProductosConStockBajo();
                            
                        case 4 -> {
                            continuar = false;
                            System.out.println("Gracias por usar el sistema.");
                        }
                            
                        default -> System.out.println("Opcion invalida. Intente nuevamente.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Entrada invalida. Por favor ingrese un numero.");
                }
            }
        }
    }
}